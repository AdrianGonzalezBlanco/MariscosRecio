﻿using MySql.Data.MySqlClient;
using System;
using System.Data.SqlClient;
using System.Windows;

namespace MariscosRecioAPK
{
    public partial class MainWindow : Window
    {
        string connectionString = "Server=10.18.48.199;Port=3306;Database=mariscos_recio;Uid=usuario;Pwd=12345;";


        public MainWindow()
        {
            InitializeComponent();
            ConfigurarVentana();
        }

        private void ConfigurarVentana()
        {
            double anchoPantalla = SystemParameters.PrimaryScreenWidth;
            double altoPantalla = SystemParameters.PrimaryScreenHeight;

            this.Width = anchoPantalla * 0.8;
            this.Height = altoPantalla * 0.8;
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;
        }

        private void BtnClientes_Click(object sender, RoutedEventArgs e)
        {
            txtTituloSeccion.Text = "Gestión de Clientes";
            
        }

        private void BtnAlmacen_Click(object sender, RoutedEventArgs e)
        {
            txtTituloSeccion.Text = "Control de Almacén";
            CargarProductos(); // Llama a la función que llena el ListBox
           /* welcomePanel.Visibility = Visibility.Hidden;
            lstProductos.Visibility = Visibility.Visible;*/
            // Futuro código de almacén
        }

        private void BtnPedidos_Click(object sender, RoutedEventArgs e)
        {
            txtTituloSeccion.Text = "Pedidos en Curso";
            // Futuro código de pedidos
        }

        private void BtnSalir_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("¿Cerrar Mariscos Recio?", "Salir", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                Application.Current.Shutdown();
            }
        }

        //cargar clientes
        private void CargarProductos()
        {
            try
            {
                lstProductos.Items.Clear();

                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT nombre FROM producto";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        lstProductos.Items.Add(reader.GetString("nombre"));
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al conectar a la base de datos: " + ex.Message);
            }
        }
    }
}
