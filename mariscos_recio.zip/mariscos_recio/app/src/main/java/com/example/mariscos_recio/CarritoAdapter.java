package com.example.mariscos_recio;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;

public class CarritoAdapter extends ArrayAdapter<Producto> {

    public CarritoAdapter(Context context, List<Producto> productos) {
        super(context, 0, productos);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext())
                    .inflate(R.layout.carrito_item, parent, false);
        }

        Producto producto = getItem(position);

        ImageView image = convertView.findViewById(R.id.itemImage);
        TextView nombre = convertView.findViewById(R.id.itemText);
        TextView precio = convertView.findViewById(R.id.itemPrecio);

        image.setImageResource(producto.getImagen());
        nombre.setText(producto.getNombre());
        precio.setText(producto.getPrecio() + "€");

        return convertView;
    }
}
