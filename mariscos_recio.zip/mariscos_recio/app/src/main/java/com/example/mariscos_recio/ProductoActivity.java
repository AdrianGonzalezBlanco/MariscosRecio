package com.example.mariscos_recio;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class ProductoActivity extends AppCompatActivity {

    private TextView nombre, precio, descripcion;
    private ImageView imagen, estrellas;
    private Button btnComprar;
    private ImageButton btnHome, btnCatalogo, btnNosotros;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_producto);

        // Views
        nombre = findViewById(R.id.productoNombre);
        precio = findViewById(R.id.productoPrecio);
        descripcion = findViewById(R.id.productoDescripcion);
        imagen = findViewById(R.id.productoImagen);
        estrellas = findViewById(R.id.productoEstrellas);
        btnComprar = findViewById(R.id.buttonComprar);

        // Menú inferior
        btnHome = findViewById(R.id.imageButton);
        btnCatalogo = findViewById(R.id.imageButton2);
        btnNosotros = findViewById(R.id.imageButton3);

        btnHome.setOnClickListener(v -> startActivity(new Intent(this, MainActivity.class)));
        btnCatalogo.setOnClickListener(v -> startActivity(new Intent(this, SegundaActivity.class)));
        btnNosotros.setOnClickListener(v -> startActivity(new Intent(this, SobreNosotros.class)));

        // Recoger datos del producto
        String nombreProd = getIntent().getStringExtra("nombre");
        double precioProd = getIntent().getDoubleExtra("precio", 0);
        int imagenProd = getIntent().getIntExtra("imagen", R.drawable.ic_launcher_foreground);
        int estrellasProd = getIntent().getIntExtra("estrellas", R.drawable.estrellas);

        // Mostrar en UI
        nombre.setText(nombreProd);
        precio.setText(String.format("%.2f€", precioProd));
        imagen.setImageResource(imagenProd);
        estrellas.setImageResource(estrellasProd);

        // Selección de descripción según el nombre del producto
        switch (nombreProd) {
            case "Caviar":
                descripcion.setText(getResources().getString(R.string.texto_caviar));
                break;
            case "Bogavante":
                descripcion.setText(getResources().getString(R.string.texto_bogavante));
                break;
            case "Pulpo":
                descripcion.setText(getResources().getString(R.string.texto_pulpo));
                break;
            case "Vieiras":
                descripcion.setText(getResources().getString(R.string.texto_vieiras));
                break;
            case "Erizo de mar":
                descripcion.setText(getResources().getString(R.string.texto_erizo));
                break;
            case "Langostinos":
                descripcion.setText(getResources().getString(R.string.texto_langostinos));
                break;
            case "Almejas":
                descripcion.setText(getResources().getString(R.string.texto_almeja));
                break;
            case "Cangrejo":
                descripcion.setText(getResources().getString(R.string.texto_cangrejo));
                break;
            default:
                descripcion.setText("Descripción no disponible.");
        }

        // Botón comprar
        btnComprar.setOnClickListener(v -> {
            Producto p = new Producto(nombreProd, imagenProd, estrellasProd, precioProd);
            Carrito.getInstance().addProducto(p);
        });
    }
}