package com.example.mariscos_recio;

import java.io.Serializable;

public class Producto implements Serializable {
    private String nombre;
    private int imagen;
    private int estrellas;
    private double precio;

    public Producto(String nombre, int imagen, int estrellas, double precio) {
        this.nombre = nombre;
        this.imagen = imagen;
        this.estrellas = estrellas;
        this.precio = precio;
    }

    public String getNombre() { return nombre; }
    public int getImagen() { return imagen; }
    public int getEstrellas() { return estrellas; }
    public double getPrecio() { return precio; }
}

