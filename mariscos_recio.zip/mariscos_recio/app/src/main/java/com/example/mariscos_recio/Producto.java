package com.example.mariscos_recio;

public class Producto {
    private String nombre;
    private int imagen;
    private int estrellas;

    public Producto(String nombre, int imagen, int estrellas) {
        this.nombre = nombre;
        this.imagen = imagen;
        this.estrellas = estrellas;
    }

    public String getNombre() { return nombre; }
    public int getImagen() { return imagen; }
    public int getEstrellas() { return estrellas; }
}