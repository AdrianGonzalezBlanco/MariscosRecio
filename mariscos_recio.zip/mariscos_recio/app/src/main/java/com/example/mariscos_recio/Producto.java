package com.example.mariscos_recio;

public class Producto {
    private String nombre;
    private int imagen;
    private int estrellas;
    private double precio;
    private Class<?> actividadDetalles; // Solo para lista de productos

    // Constructor para la lista de productos
    public Producto(String nombre, int imagen, int estrellas, Class<?> actividadDetalles, double precio) {
        this.nombre = nombre;
        this.imagen = imagen;
        this.estrellas = estrellas;
        this.actividadDetalles = actividadDetalles;
        this.precio = precio;
    }

    // Constructor para productos del carrito
    public Producto(String nombre, int imagen, int estrellas, double precio) {
        this.nombre = nombre;
        this.imagen = imagen;
        this.estrellas = estrellas;
        this.precio = precio;
    }

    // Getters
    public String getNombre() { return nombre; }
    public int getImagen() { return imagen; }
    public int getEstrellas() { return estrellas; }
    public double getPrecio() { return precio; }
    public Class<?> getActividadDetalles() { return actividadDetalles; }
}
