package com.example.mariscos_recio;

public class Producto {
    private String nombre;
    private int imagen;
    private int estrellas;
    private Class<?> actividadDetalles; // Activity de detalles asociada

    public Producto(String nombre, int imagen, int estrellas, Class<?> actividadDetalles) {
        this.nombre = nombre;
        this.imagen = imagen;
        this.estrellas = estrellas;
        this.actividadDetalles = actividadDetalles;
    }

    public String getNombre() {
        return nombre;
    }

    public int getImagen() {
        return imagen;
    }

    public int getEstrellas() {
        return estrellas;
    }

    public Class<?> getActividadDetalles() {
        return actividadDetalles; // Devuelve la Activity de detalles asociada
    }
}

