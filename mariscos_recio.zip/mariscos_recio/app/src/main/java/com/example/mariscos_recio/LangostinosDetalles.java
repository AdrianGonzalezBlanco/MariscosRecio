package com.example.mariscos_recio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class LangostinosDetalles extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_langostinos);

        ImageButton imageButton2 = findViewById(R.id.imageButton2);

        //Volver al SegundaActivity (Carrito)
        imageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LangostinosDetalles.this, SegundaActivity.class);
                startActivity(intent);
            }
        });

        ImageButton imageButton = findViewById(R.id.imageButton);
        //Volver al MainActivity (Casa)
        imageButton.setOnClickListener(view -> {
            Intent intent = new Intent(LangostinosDetalles.this, MainActivity.class);
            startActivity(intent);
        });

        ImageButton imageButton3 = findViewById(R.id.imageButton3);
        // Ir a Sobre Nosotros (Personas)
        imageButton3.setOnClickListener(view -> {
            Intent intent = new Intent(LangostinosDetalles.this, SobreNosotros.class);
            startActivity(intent);
        });
    }
}