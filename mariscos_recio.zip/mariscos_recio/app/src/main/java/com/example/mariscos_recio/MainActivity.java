package com.example.mariscos_recio;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Carga el layout de la Activity

        //Referencias a usuario, contraseña y el botón de aceptar
        EditText editUsuario = findViewById(R.id.editUsuario);
        EditText editContrasena = findViewById(R.id.introContrasena);
        Button btnAceptar = findViewById(R.id.button);

        btnAceptar.setOnClickListener(v -> {
            String usuario = editUsuario.getText().toString().trim();
            String contrasena = editContrasena.getText().toString().trim();

            //Comprueba que los campos no estén vacíos
            if (usuario.isEmpty() || contrasena.isEmpty()) {
                Toast.makeText(this, "Completa todos los campos.", Toast.LENGTH_SHORT).show();
            } else {
                // Verifica si el inicio de sesion es correcto
                if (usuario.equals("CapitanPescaNova") && contrasena.equals("12345")) {
                    Toast.makeText(this, "Inicio de sesión exitoso.", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(this, SegundaActivity.class)); //Abre la siguiente Activity
                } else {
                    Toast.makeText(this, "Usuario o contraseña incorrectos.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}