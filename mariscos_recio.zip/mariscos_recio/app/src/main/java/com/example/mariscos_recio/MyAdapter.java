package com.example.mariscos_recio;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class MyAdapter extends ArrayAdapter<Producto> {

    public MyAdapter(Context context, List<Producto> productos) {
        super(context, 0, productos);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext())
                    .inflate(R.layout.list_item, parent, false);
        }

        Producto producto = getItem(position);

        ImageView image = convertView.findViewById(R.id.itemImage);
        TextView text = convertView.findViewById(R.id.itemText);
        ImageView estrellas = convertView.findViewById(R.id.itemEstrellas);

        image.setImageResource(producto.getImagen());
        text.setText(producto.getNombre());
        estrellas.setImageResource(producto.getEstrellas());

        return convertView;
    }
}


