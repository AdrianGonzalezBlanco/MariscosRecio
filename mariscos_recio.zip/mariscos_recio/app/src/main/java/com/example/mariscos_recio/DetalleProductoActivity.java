package com.example.mariscos_recio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class DetalleProductoActivity extends AppCompatActivity {

    private TextView nombre, precio;
    private ImageView imagen, estrellas;
    private Button btnComprar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_producto);

        nombre = findViewById(R.id.productoNombre);
        precio = findViewById(R.id.productoPrecio);
        imagen = findViewById(R.id.productoImagen);
        estrellas = findViewById(R.id.productoEstrellas);
        btnComprar = findViewById(R.id.buttonComprar);

        //Recoge los datos enviados desde otra actividad
        Intent intent = getIntent();
        if (intent != null) {
            nombre.setText(intent.getStringExtra("nombre"));
            precio.setText(intent.getDoubleExtra("precio", 0) + "€");
            imagen.setImageResource(intent.getIntExtra("imagen", R.drawable.ic_launcher_foreground));
            estrellas.setImageResource(intent.getIntExtra("estrellas", R.drawable.estrellas));
        }

        //Botón comprar
        btnComprar.setOnClickListener(v -> {
            Producto p = new Producto( //Crea producto
                    nombre.getText().toString(),
                    intent.getIntExtra("imagen", R.drawable.ic_launcher_foreground),
                    intent.getIntExtra("estrellas", R.drawable.estrellas),
                    intent.getDoubleExtra("precio", 0)
            );
            Carrito.getInstance().agregarProducto(p); //Añade el producto al carrito
        });
    }
}