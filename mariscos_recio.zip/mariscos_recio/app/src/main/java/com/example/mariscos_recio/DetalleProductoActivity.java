package com.example.mariscos_recio;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DetalleProductoActivity extends AppCompatActivity {

    TextView tvNombre;
    ImageView ivImagen, ivEstrellas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_producto);

        tvNombre = findViewById(R.id.tvNombre);
        ivImagen = findViewById(R.id.ivImagen);
        ivEstrellas = findViewById(R.id.ivEstrellas);

        // Recibir datos del Intent
        String nombre = getIntent().getStringExtra("nombre");
        int imagen = getIntent().getIntExtra("imagen", 0);
        int estrellas = getIntent().getIntExtra("estrellas", 0);

        // Mostrar datos
        tvNombre.setText(nombre);
        ivImagen.setImageResource(imagen);
        ivEstrellas.setImageResource(estrellas);
    }
}

