package com.example.mariscos_recio;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;

public class ErizoDetalles extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_erizo);

        // Referencia al botón "Volver"
        Button buttonVolver = findViewById(R.id.buttonVolver);

        // Al clicar, cerramos esta Activity y volvemos a SegundaActivity
        buttonVolver.setOnClickListener(v -> finish());
    }
}