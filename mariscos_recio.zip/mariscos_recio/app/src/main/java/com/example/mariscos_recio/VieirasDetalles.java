package com.example.mariscos_recio;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class VieirasDetalles extends AppCompatActivity {

    private Button btnComprar;
    private ImageButton btnInicio, btnCatalogo, btnNosotros;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vieiras);

        // Referencias a los botones
        btnComprar = findViewById(R.id.button1);
        btnInicio = findViewById(R.id.imageButton);
        btnCatalogo = findViewById(R.id.imageButton2);
        btnNosotros = findViewById(R.id.imageButton3);

        // Botón Inicio
        btnInicio.setOnClickListener(v -> {
            startActivity(new Intent(VieirasDetalles.this, MainActivity.class));
        });

        // Botón Catálogo
        btnCatalogo.setOnClickListener(v -> {
            startActivity(new Intent(VieirasDetalles.this, SegundaActivity.class));
        });

        // Botón Sobre Nosotros
        btnNosotros.setOnClickListener(v -> {
            startActivity(new Intent(VieirasDetalles.this, SobreNosotros.class));
        });

        // Botón Comprar: añade Vieiras al carrito
        btnComprar.setOnClickListener(v -> {
            Producto vieiras = new Producto("Vieiras", R.drawable.vieiras, R.drawable.estrellas, 14.99);
            Carrito.getInstance().agregarProducto(vieiras);
        });

    }
}