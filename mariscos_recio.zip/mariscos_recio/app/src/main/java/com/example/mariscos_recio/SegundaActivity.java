package com.example.mariscos_recio;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.ImageButton;
import java.util.ArrayList;

public class SegundaActivity extends AppCompatActivity {

    private ListView listView;
    private SearchView searchView;
    private ArrayList<Producto> lista;
    private MyAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda);

        listView = findViewById(R.id.listView);
        searchView = findViewById(R.id.searchView);

        // Botones
        ImageButton btnInicio = findViewById(R.id.imageButton);
        ImageButton btnNosotros = findViewById(R.id.imageButton3);
        ImageButton btnCarrito = findViewById(R.id.botonCarrito);

        btnInicio.setOnClickListener(v -> startActivity(new Intent(this, MainActivity.class)));
        btnNosotros.setOnClickListener(v -> startActivity(new Intent(this, SobreNosotros.class)));
        btnCarrito.setOnClickListener(v -> startActivity(new Intent(this, CarritoActivity.class)));

        // Lista de productos
        lista = new ArrayList<>();
        lista.add(new Producto("Caviar", R.drawable.caviar, R.drawable.estrellas, CaviarDetalles.class, 29.99));
        lista.add(new Producto("Bogavante", R.drawable.bogavante, R.drawable.estrellas, BogavanteDetalles.class, 19.99));
        lista.add(new Producto("Pulpo", R.drawable.pulpo, R.drawable.estrellas, PulpoDetalles.class, 24.99));
        lista.add(new Producto("Vieiras", R.drawable.vieiras, R.drawable.estrellas, VieirasDetalles.class, 14.99));
        lista.add(new Producto("Erizo de mar", R.drawable.erizo, R.drawable.estrellas, ErizoDetalles.class, 9.99));
        lista.add(new Producto("Langostinos", R.drawable.langostinos, R.drawable.estrellas, LangostinosDetalles.class, 15.99));
        lista.add(new Producto("Almejas", R.drawable.almeja, R.drawable.estrellas, AlmejaDetalles.class, 4.99));
        lista.add(new Producto("Cangrejo", R.drawable.cangrejo, R.drawable.estrellas, CangrejoDetalles.class, 17.99));


        adapter = new MyAdapter(this, lista);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            Producto seleccionado = (Producto) parent.getItemAtPosition(position);

            Intent intent = new Intent(SegundaActivity.this, seleccionado.getActividadDetalles());
            startActivity(intent);
        });



        // Buscador
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override public boolean onQueryTextSubmit(String query) { return false; }
            @Override
            public boolean onQueryTextChange(String newText) {
                ArrayList<Producto> filtrados = new ArrayList<>();
                for (Producto p : lista) {
                    if (p.getNombre().toLowerCase().contains(newText.toLowerCase())) {
                        filtrados.add(p);
                    }
                }
                adapter = new MyAdapter(SegundaActivity.this, filtrados);
                listView.setAdapter(adapter);
                return true;
            }
        });
    }
}



