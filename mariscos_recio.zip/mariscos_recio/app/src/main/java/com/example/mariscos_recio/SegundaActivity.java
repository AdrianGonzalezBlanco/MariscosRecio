package com.example.mariscos_recio;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.ImageButton;
import java.util.ArrayList;

public class SegundaActivity extends AppCompatActivity {

    private ListView listView;
    private SearchView searchView;
    private ArrayList<Producto> lista;
    private MyAdapter adapter;
    private ImageButton imageButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda);

        listView = findViewById(R.id.listView);
        searchView = findViewById(R.id.searchView);

        //Ir a Iniciar Sesion (Casa)
        imageButton = findViewById(R.id.imageButton);
        imageButton.setOnClickListener(v -> {
            Intent intent = new Intent(SegundaActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });

        ImageButton imageButton3 = findViewById(R.id.imageButton3);
        // Ir a Sobre Nosotros (Personas)
        imageButton3.setOnClickListener(view -> {
            Intent intent = new Intent(SegundaActivity.this, SobreNosotros.class);
            startActivity(intent);
        });

        // Lista de productos con la Activity de detalles correspondiente
        lista = new ArrayList<>();
        lista.add(new Producto("Caviar", R.drawable.caviar, R.drawable.estrellas, CaviarDetalles.class));
        lista.add(new Producto("Bogavante", R.drawable.bogavante, R.drawable.estrellas, BogavanteDetalles.class));
        lista.add(new Producto("Pulpo", R.drawable.pulpo, R.drawable.estrellas, PulpoDetalles.class));
        lista.add(new Producto("Vieiras", R.drawable.vieiras, R.drawable.estrellas, VieirasDetalles.class));
        lista.add(new Producto("Erizo de mar", R.drawable.erizo, R.drawable.estrellas, ErizoDetalles.class));
        lista.add(new Producto("Langostinos", R.drawable.langostinos, R.drawable.estrellas, LangostinosDetalles.class));
        lista.add(new Producto("Almejas", R.drawable.almeja, R.drawable.estrellas, AlmejaDetalles.class));
        lista.add(new Producto("Cangrejo", R.drawable.cangrejo, R.drawable.estrellas, CangrejoDetalles.class));

        // Adapter
        adapter = new MyAdapter(this, lista);
        listView.setAdapter(adapter);

        // Listener para clic en cada elemento de la lista
        listView.setOnItemClickListener((parent, view, position, id) -> {
            Producto seleccionado = (Producto) parent.getItemAtPosition(position);
            startActivity(new Intent(this, seleccionado.getActividadDetalles()));
        });

        // Buscador
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) { return false; }

            @Override
            public boolean onQueryTextChange(String newText) {
                ArrayList<Producto> filtrados = new ArrayList<>();
                for (Producto p : lista) {
                    if (p.getNombre().toLowerCase().contains(newText.toLowerCase())) {
                        filtrados.add(p);
                    }
                }
                adapter = new MyAdapter(SegundaActivity.this, filtrados);
                listView.setAdapter(adapter);
                return true;
            }
        });
    }
}



