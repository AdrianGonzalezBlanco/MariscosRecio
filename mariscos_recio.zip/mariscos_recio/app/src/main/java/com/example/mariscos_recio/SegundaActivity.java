package com.example.mariscos_recio;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SearchView;

import java.util.ArrayList;

public class SegundaActivity extends AppCompatActivity {

    ListView listView;
    SearchView searchView;

    ArrayList<Producto> lista;
    MyAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda);

        listView = findViewById(R.id.listView);
        searchView = findViewById(R.id.searchView);

        //Lista de Productos
        lista = new ArrayList<>();
        lista.add(new Producto("Caviar", R.drawable.caviar, R.drawable.estrellas));
        lista.add(new Producto("Bogavante", R.drawable.bogavante, R.drawable.estrellas));
        lista.add(new Producto("Pulpo", R.drawable.pulpo, R.drawable.estrellas));
        lista.add(new Producto("Vieiras", R.drawable.vieiras, R.drawable.estrellas));
        lista.add(new Producto("Erizo de mar", R.drawable.erizo, R.drawable.estrellas));
        lista.add(new Producto("Langostinos", R.drawable.langostinos, R.drawable.estrellas));

        adapter = new MyAdapter(this, lista);
        listView.setAdapter(adapter);

        //Busqueda
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                ArrayList<Producto> filtrados = new ArrayList<>();

                for (Producto p : lista) {
                    if (p.getNombre().toLowerCase().contains(newText.toLowerCase())) {
                        filtrados.add(p);
                    }
                }

                MyAdapter nuevoAdapter =
                        new MyAdapter(SegundaActivity.this, filtrados);
                listView.setAdapter(nuevoAdapter);

                return true;
            }
        });
    }
}
