package com.example.mariscos_recio;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.ImageButton;
import java.util.ArrayList;

public class SegundaActivity extends AppCompatActivity {

    private ListView listView;
    private SearchView searchView;
    private ArrayList<Producto> lista;
    private MyAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda);

        // Referencias a vistas
        listView = findViewById(R.id.listViewCarrito);
        searchView = findViewById(R.id.searchView);

        ImageButton btnInicio = findViewById(R.id.imageButton);
        ImageButton btnCatalogo = findViewById(R.id.imageButton2);
        ImageButton btnNosotros = findViewById(R.id.imageButton3);
        ImageButton btnCarrito = findViewById(R.id.botonCarrito); // ← AÑADIDO

        // Eventos del menú inferior
        btnInicio.setOnClickListener(v -> startActivity(new Intent(this, MainActivity.class)));
        btnCatalogo.setOnClickListener(v -> startActivity(new Intent(this, SegundaActivity.class)));
        btnNosotros.setOnClickListener(v -> startActivity(new Intent(this, SobreNosotros.class)));

        // Abre el Carrito
        btnCarrito.setOnClickListener(v ->
                startActivity(new Intent(this, CarritoActivity.class))
        );

        // Lista de productos
        lista = new ArrayList<>();
        lista.add(new Producto("Caviar", R.drawable.caviar, R.drawable.estrellas, 29.99));
        lista.add(new Producto("Bogavante", R.drawable.bogavante, R.drawable.estrellas, 19.99));
        lista.add(new Producto("Pulpo", R.drawable.pulpo, R.drawable.estrellas, 24.99));
        lista.add(new Producto("Vieiras", R.drawable.vieiras, R.drawable.estrellas, 14.99));
        lista.add(new Producto("Erizo de mar", R.drawable.erizo, R.drawable.estrellas, 9.99));
        lista.add(new Producto("Langostinos", R.drawable.langostinos, R.drawable.estrellas, 15.99));
        lista.add(new Producto("Almejas", R.drawable.almeja, R.drawable.estrellas, 4.99));
        lista.add(new Producto("Cangrejo", R.drawable.cangrejo, R.drawable.estrellas, 17.99));

        // Adaptador
        adapter = new MyAdapter(this, lista);
        listView.setAdapter(adapter);

        // Click en producto -> abrir ProductoActivity
        listView.setOnItemClickListener((parent, view, position, id) -> {
            Producto seleccionado = adapter.getItem(position);

            if (seleccionado != null) {
                Intent intent = new Intent(SegundaActivity.this, ProductoActivity.class);
                intent.putExtra("nombre", seleccionado.getNombre());
                intent.putExtra("imagen", seleccionado.getImagen());
                intent.putExtra("precio", seleccionado.getPrecio());
                intent.putExtra("estrellas", seleccionado.getEstrellas());
                startActivity(intent);
            }
        });

        // Buscador
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override public boolean onQueryTextSubmit(String query) { return false; }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.filtrar(newText);
                return true;
            }
        });
    }
}
