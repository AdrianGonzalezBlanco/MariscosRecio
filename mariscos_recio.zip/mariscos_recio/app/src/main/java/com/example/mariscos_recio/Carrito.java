package com.example.mariscos_recio;

import java.util.ArrayList;

public class Carrito {
    private static Carrito instance;
    private ArrayList<Producto> productos;

    private Carrito() {
        productos = new ArrayList<>();
    }

    public static Carrito getInstance() {
        if (instance == null) {
            instance = new Carrito();
        }
        return instance;
    }

    public ArrayList<Producto> getProductos() { return productos; }

    public void agregarProducto(Producto producto) {
        productos.add(producto);
    }

    public void eliminarProducto(Producto producto) {
        productos.remove(producto);
    }
}
