package com.example.mariscos_recio;

import java.util.ArrayList;

public class Carrito {

    private static Carrito instance;
    private ArrayList<Producto> productos;

    private Carrito() {
        productos = new ArrayList<>();
    }

    public static Carrito getInstance() {
        if (instance == null) {
            instance = new Carrito();
        }
        return instance;
    }

    public ArrayList<Producto> getProductos() { return productos; }

    public void addProducto(Producto producto) {
        if (producto != null) productos.add(producto);
    }

    public void removeProducto(Producto producto) { productos.remove(producto); }

    public void clear() { productos.clear(); }

    public double getTotal() {
        double total = 0;
        for (Producto p : productos) total += p.getPrecio();
        return total;
    }
}