package com.example.mariscos_recio;

public class CaviarDetalles {
}
