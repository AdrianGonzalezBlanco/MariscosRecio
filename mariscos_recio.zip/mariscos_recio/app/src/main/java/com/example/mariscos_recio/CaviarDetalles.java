package com.example.mariscos_recio;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class CaviarDetalles extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caviar);

        ImageButton imageButton2 = findViewById(R.id.imageButton2);

        //Volver al SegundaActivity (Carrito)
        imageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CaviarDetalles.this, SegundaActivity.class);
                startActivity(intent);
            }
        });

        ImageButton imageButton = findViewById(R.id.imageButton);
        //Volver al MainActivity (Casa)
        imageButton.setOnClickListener(view -> {
            Intent intent = new Intent(CaviarDetalles.this, MainActivity.class);
            startActivity(intent);
        });

        ImageButton imageButton3 = findViewById(R.id.imageButton3);
        // Ir a Sobre Nosotros (Personas)
        imageButton3.setOnClickListener(view -> {
            Intent intent = new Intent(CaviarDetalles.this, SobreNosotros.class);
            startActivity(intent);
        });
    }
}